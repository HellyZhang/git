package cn.tedu.ttms.system.dao;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.system.entity.Organization;

public interface OrganizationDao extends BaseDao<Organization> {

}
