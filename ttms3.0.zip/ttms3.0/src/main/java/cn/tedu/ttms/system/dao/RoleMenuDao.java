package cn.tedu.ttms.system.dao;


import java.util.List;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.system.entity.RoleMenu;

public interface RoleMenuDao extends BaseDao<RoleMenu> {
	List<Integer> findMenuIdListByRoleId(Integer roleId);
}
