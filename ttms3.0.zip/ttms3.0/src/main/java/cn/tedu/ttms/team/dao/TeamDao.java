package cn.tedu.ttms.team.dao;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.team.entity.Team;

public interface TeamDao extends BaseDao<Team> {

}
