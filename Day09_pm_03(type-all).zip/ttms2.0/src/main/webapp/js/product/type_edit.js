var zTree;
$(document).ready(function(){
	
	$("#editTypeForm").on("click",".load-product-type",loadTypeTree);
	$("#typeLayer").on("click",".btn-cancle",hideTypeTree);
	$("#typeLayer").on("click",".btn-confirm",setSelectedTypeNode);
    $("#btn-save").click(doSaveOrUpdate);
});
//定义zTree树的基本配置
var setting = {
		data : {   
			simpleData : {
				enable : true,
				idKey : "id",  //节点数据中保存唯一标识的属性名称
				pIdKey : "parentId",  //节点数据中保存其父节点唯一标识的属性名称
				rootPId : null  //根节点id
			}
		}
}
//执行保存或更新的动作
function doSaveOrUpdate(){
	//1.获得表单数据
	var params=getEditFormData();
	//2.提交表单数据
	var url="productType/doSaveObject.do";
	$.post(url,params,function(result){
		if(result.state==1){
			alert("save ok");
			$("#container").load("productType/listUI.do?t="+Math.random(1000));
		}else{
			alert(result.message);
		}
	});
}
/*获得表单数据*/
function getEditFormData(){
	var params={
	   "name":$("#typeNameId").val(),
	   "parentId":$("#editTypeForm").data("parentId"),
	   "sort":$("#typeSortId").val(),
	   "note":$("#typeNoteId").val()
	};
	return params;
}

//隐藏typetree
function hideTypeTree(){
	$("#typeLayer").css("display","none");
}

//设置选中的type节点
function setSelectedTypeNode(){
	//获得zTree中选中的节点(jquery.ztree.all.min.js)
	var nodes=zTree.getSelectedNodes();
	//获得选中的第一个节点
	var node=nodes[0];
	//给parentNameId的赋值
	$("#parentNameId").val(node.name);//显示的是名字
	//将id的值绑定到editTypeForm对象上
	$("#editTypeForm").data("parentId",node.id)//保存到数据库的应该是parentId值
	//隐藏zTree树对象
	$("#typeLayer").css("display","none");
}
//加载产品分类信息,然后以zTree形式显示
function loadTypeTree(){	
	//显示zTree树
	$("#typeLayer").css("display","block");//none
	//初始化zTree的
	var url="productType/doFindTreeNodes.do";//??? (dao-->mappper)-->service-->controller
	$.getJSON(url,function(result){
		console.log(JSON.stringify(result.data))
		if(result.state==1){
			//初始化zTree;
			  zTree=$.fn.zTree.init(
			  $("#typeTree"),//显示树的位置
			  setting,//树的基本配置
			  result.data);//树上要显示的数据
		}else{
			alert(result.message);
		}
	});
}